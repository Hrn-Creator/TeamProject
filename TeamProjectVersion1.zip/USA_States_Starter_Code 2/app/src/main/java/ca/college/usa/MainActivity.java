package ca.college.usa;



import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Random;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;


/**
 * Full Name:
 *
 * Student ID:
 *
 * Course: CST3104
 *
 * Term:  Fall 2022
 *
 * Assignment: Team Project
 *
 * Date :
 */

public class MainActivity extends AppCompatActivity {

    private static final String sFileName = "usa.json";

    // ListView <---> adapter <---> data
    private ArrayAdapter<State> mAdapter;
    private ListView mlistView;

    // Data Source for the Adapter
    private ArrayList<State> mStatesList;
    int counter1 = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Load the data needed for the adapter
        mStatesList = State.readData(this, sFileName );

        mlistView = findViewById(R.id.listView);

        mAdapter = new ArrayAdapter<>(this,
                                       android.R.layout.simple_list_item_1,
                                        mStatesList);

        mlistView.setAdapter(mAdapter);
        Random r = new Random();
        AtomicInteger result = new AtomicInteger(r.nextInt(49));
        AtomicReference<ImageView> image = new AtomicReference<>(findViewById(R.id.imageView));
        AtomicInteger imageResource = new AtomicInteger(this.getResources().getIdentifier("@drawable/" + mStatesList.get(result.get()).getDrawable().toLowerCase(), null, this.getPackageName()));
        AtomicReference<Drawable> res = new AtomicReference<>(this.getDrawable(imageResource.get()));
        image.get().setImageDrawable(res.get());


        TextView counterID = findViewById(R.id.counterID);
        ImageButton playID = findViewById(R.id.playID);


        playID.setOnClickListener(click -> {

             result.set(r.nextInt(49));
             image.set(findViewById(R.id.imageView));
             imageResource.set(this.getResources().getIdentifier("@drawable/" + mStatesList.get(result.get()).getDrawable().toLowerCase(), null, this.getPackageName()));
              res.set(this.getDrawable(imageResource.get()));
            image.get().setImageDrawable(res.get());

            counter1= 0;
            counterID.setText(""+counter1);
            counterID.setTextColor(Color.GRAY);

        });



// click events for lv
        mlistView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                if (mStatesList.get(result.get()).getName().equals(mStatesList.get(position).getName())){


                    Toast.makeText(MainActivity.this, " Correct " + mAdapter.getItem(position), Toast.LENGTH_SHORT).show();
                    counterID.setTextColor(Color.GREEN);
                } else {
                    counter1=counter1+1;
                    counterID.setText(""+counter1);
                    counterID.setTextColor(Color.RED);
                    Toast.makeText(MainActivity.this, " Incorrect, Please try again ", Toast.LENGTH_SHORT).show();

                }

            }
        });






    }


}